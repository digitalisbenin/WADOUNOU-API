<?php return array (
  'show-abonnements' => 'App\\Http\\Livewire\\ShowAbonnements',
  'show-categories' => 'App\\Http\\Livewire\\ShowCategories',
  'show-clients' => 'App\\Http\\Livewire\\ShowClients',
  'show-commandes' => 'App\\Http\\Livewire\\ShowCommandes',
  'show-commentaires' => 'App\\Http\\Livewire\\ShowCommentaires',
  'show-livraisons' => 'App\\Http\\Livewire\\ShowLivraisons',
  'show-livreurs' => 'App\\Http\\Livewire\\ShowLivreurs',
  'show-repas' => 'App\\Http\\Livewire\\ShowRepas',
  'show-reservations' => 'App\\Http\\Livewire\\ShowReservations',
  'show-restaurants' => 'App\\Http\\Livewire\\ShowRestaurants',
  'show-roles' => 'App\\Http\\Livewire\\ShowRoles',
  'show-users' => 'App\\Http\\Livewire\\ShowUsers',
);